package com.example.secretstoriesuiv01;

public interface BtnClickListener {
    public abstract void onBtnClick(int position);
}
